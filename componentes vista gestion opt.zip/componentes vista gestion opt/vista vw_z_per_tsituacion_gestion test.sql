USE [exelix_test]
GO

/****** Object:  View [operacional].[vw_z_per_tsituacion_gestion]    Script Date: 09/04/2026 11:20:49 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE VIEW [operacional].[vw_z_per_tsituacion_gestion]

AS
SELECT 
	per.id_persona,
	dias_mora,
	isnull (deuda_a_vencer,0) deuda_a_vencer,
	isnull(deuda_vencida,0) deuda_vencida,
	isnull(deuda_vencida,0) + CASE WHEN isnull(deuda_a_vencer,0) >= 0 THEN isnull(deuda_a_vencer,0) ELSE 0 END deuda_total,
	sit.id_objeto,
	ISNULL(sit.id_objeto_gestion, per.id_persona) id_objeto_gestion_asim,
	sit.id_objeto_gestion,
	per.id_empresa,
	sit.id_workflow,
	sit.nombre_workflow,
	sit.codigo_vista_gestion,
	sit.id_escenario,
	sit.codigo_escenario,
	sit.fecha_escenario,
	sit.id_estrategia,
	sit.codigo_estrategia,
	sit.fecha_estrategia,
	sit.id_estado,
	sit.codigo_estado,
	sit.fecha_estado,
	sit.fecha_ultimo_evento,
	sit.nombre_ultimo_evento,
	sit.fecha_ultima_accion,
	sit.nombre_ultima_accion,
	sit.nombre_ultima_respuesta,
	sit.dias_en_estado,
	sit.dias_en_escenario,
	ISNULL ((cod_promesas.codigo_met_estado_promesa), 'Sin Promesas') estado_ult_promesa_pago,
	isnull(pre_core.posee_telefono_valido,'N')posee_telefono_valido,
	isnull(ulacc.actualizo_telefono_en_estado,'N')actualizo_telefono_en_estado,
	isnull(pre_core.posee_domicilio_valido,'N')posee_domicilio_valido,
	isnull(ulacc.actualizo_domicilio_en_estado,'N')actualizo_domicilio_en_estado,
    isnull(pre_core.posee_mail_valido,'N')posee_mail_valido,
	datediff(day, ulacc.max_alta_fecha, (tblParametros.fec_cierre)) dias_ultimo_llamado,
	isnull(ulacc.cantidad_llamados,0)cantidad_llamados,
	isnull(ueve.cantidad_envios_cartas,0)cantidad_envios_cartas,
	isnull(pre_core.posee_telefono_celular,'N')posee_telefono_celular,
	isnull(ulacc.marca_siniestro,'N')marca_siniestro,
    isnull(ulacc.marca_usurp_identidad,'N')marca_usurp_identidad,
    isnull(ulacc.marca_exceptuado,'N')marca_exceptuado,
    isnull(ulacc.marca_anul_fallecido,'N')marca_anul_fallecido,
	pre_core.agencia,
	isnull(ueve.cant_gest_post_est,0)cant_gest_post_est,
    isnull(ulacc.cantidad_llamados_est,0)cantidad_llamados_est,
	isnull(UltLlamCierre.codigo,'Sin accion') resp_ult_llm_cie,
	isnull(Tbresp_ult_llm_est.codigo,'Sin Accion') resp_ult_llm_est,
	isnull(ulacc.cant_llm_post_ult10dias,0)cant_llm_post_ult10dias,
	isnull(ulacc.pase_adelantado,'N')pase_adelantado,
	isnull(ulacc.prom_refi_est,'N')prom_refi_est,
	per.empleado empleado, 
	isnull(ulacc.refi_caida,'N')refi_caida,
	pre_core.responsable,
	case when prmes.existe_nueva_promesa_estado > 0 then 'S' ELSE 'N' END existe_nueva_promesa_estado
	-- campos z_datos_calc_per
	,prz.cliente_fecha_ult_acredit AS cliente_fecha_ult_acredit
	,prz.per_min_fec_est AS per_min_fec_est
	,prz.per_min_fec_vto AS per_min_fec_vto
	,prz.cliente_dias_de_mora_no_cte AS Cliente_Dias_de_mora_No_CTE
	,prz.cliente_rtas_neg_lla_ultmti AS cliente_rtas_neg_lla_ultmti
	,prz.cliente_rtas_neg_llm_esc AS cliente_rtas_neg_llm_esc
	,prz.cliente_prorrogas_est AS Cliente_Prorrogas_EST
	,prz.cliente_rta_ocnoc_ult_90_d AS cliente_rta_ocnoc_ult_90_d
	,prz.cliente_gestiones_neg_est AS Cliente_Gestiones_Neg_EST
	,prz.[default] AS  "default"
	,prz.cliente_dias_de_mora AS Cliente_Dias_de_mora
	,prz.cliente_dias_en_esc AS cliente_dias_en_esc
	,prz.cliente_dias_en_est AS Cliente_Dias_en_EST
	,prz.cliente_rtas_neg_llam_auti AS Cliente_Rtas_neg_Llam_AutI
	,prz.cliente_dias_ult_accion_est AS Cliente_dias_ult_accion_EST
	,prz.cliente_cart_esp_esc AS cliente_cart_esp_esc
	,prz.cliente_cart_doc_esc AS cliente_cart_doc_esc
	,prz.cliente_cart_simp_esc AS cliente_cart_simp_esc
	,prz.cliente_posit_llm_ult_90_dias AS cliente_posit_llm_ult_90_dias
	,prz.cliente__mora_prod_refi AS cliente__mora_prod_refi
	,prz.tarjeta_fogar_mora_producto AS tarjeta_fogar_mora_producto
	,prz.cliente_cdfi_esc AS cliente_cdfi_esc
	,prz.Mora_Producto AS Mora_Producto
	,prz.ptm_fogar_mora_producto AS ptm_fogar_mora_producto
	,prz.cli_rtas_neg_micro_llam_aut_1 AS Cli_Rtas_neg_micro_Llam_Aut_1
	,prz.cli_rtas_neg_micro_llam_aut_2 AS cli_rtas_neg_micro_llam_aut_2
	,prz.oper_dias_alta AS oper_dias_alta
	,prz.oper_dias_en_estado AS oper_dias_en_estado
	,prz.dias_ult_llm AS dias_ult_llm
	,prz.cliente_monto_ult_acreditacion AS cliente_monto_ult_acreditacion
	,prz.id_cartera AS id_cartera
	,prz.id_banca AS id_banca
	,prz.id_segmento AS id_segmento
	,prz.id_sub_segmento AS id_sub_segmento
	,prz.id_categoria AS id_categoria
	,prz.cliente_score AS cliente_score
	,prz.cliente_dias_de_mora_macro AS Cliente_dias_de_mora_macro
	,prz.cliente_sucursal AS cliente_sucursal
	,prz.cliente_saldo_contable AS cliente_saldo_contable
	,prz.cli_ult_mes_acred_sueldo AS cli_ult_mes_acred_sueldo
	,prz.cliente_deuda_contable AS cliente_deuda_contable
	,prz.per_perdida_esp AS per_perdida_esp
	,prz.cliente_perdida_esperada AS cliente_perdida_esperada
	,prz.cliente_monto_deuda_vencida AS cliente_monto_deuda_vencida
	,prz.cliente_deuda_total AS Cliente_deuda_total
	,prz.cliente_deuda_total_macro AS Cliente_deuda_total_macro
	,prz.cliente_deuda_vencida_macro AS Cliente_deuda_vencida_macro
	,prz.cliente_plan_sueldo_privado AS cliente_plan_sueldo_privado
	,prz.cliente_agencia AS Cliente_Agencia
	,prz.cliente_responsableequipo AS cliente_responsableequipo
	,prz.Cliente_segmento AS Cliente_segmento
	,prz.cliente_cartera AS Cliente_cartera
	,prz.cliente_rta_ultacc_seg_ges_est AS Cliente_Rta_UltAcc_Seg_Ges_EST
	,prz.cliente_rta_ult_acc_an_pas_est AS Cliente_Rta_Ult_Acc_An_Pas_EST
	,prz.cliente_rta_ult_acc_gest_coo AS cliente_rta_ult_acc_gest_coo
	,prz.clie_rpta_ult_accion_sin_bcra AS Clie_Rpta_ult_accion_sin_BCRA
	,prz.Cliente_Fravega AS Cliente_Fravega
	,prz.cliente_producto34 AS cliente_producto34
	,prz.cliente_es_asalariado AS cliente_es_asalariado
	,prz.cliente_ultdigdocok AS cliente_ultdigdocok
	,prz.ultimios_dias_mes AS ultimios_dias_mes
	,prz.cliente_nuevo_prod_ref_est AS cliente_nuevo_prod_ref_est
	,prz.cliente_rta_ult_acc_online_est AS Cliente_rta_ult_acc_Online_EST
	,prz.cliente_rta_ult_anal_incid_adm AS Cliente_rta_ult_Anal_Incid_Adm
	,prz.cuenta_existe_en_arch_subido AS cuenta_existe_en_arch_subido
	,prz.cliente_existe_en_archivo AS cliente_existe_en_archivo
	,prz.cuenta_rtaev_rec_leg_est AS Cuenta_RtaEv_Rec_leg_EST
	,prz.cliente__producto3121 AS Cliente__Producto3121
	,prz.anula_regla AS Anula_Regla
	,prz.cliente_varias_carteras AS cliente_varias_carteras
	,prz.cliente_cprod_en_otra_cartera AS cliente_cprod_en_otra_cartera
	,prz.cliente_rta_ult_acc_an_pl_est AS Cliente_Rta_ult_acc_An_PL_EST
	,prz.cliente_plan_sueldo AS cliente_plan_sueldo
	,prz.cliente_empleado AS Cliente_Empleado
	,prz.cliente_region AS cliente_region
	,prz.cliente_responsable AS Cliente_Responsable
	,prz.cliente_calificacion_vencida AS cliente_calificacion_vencida
	,prz.cliente_baja_contable AS Cliente_baja_contable
	,prz.cliente_nueva_prom_pago_est AS Cliente_Nueva_Prom_Pago_EST
	,prz.cliente_promesa_pago_rota_est AS Cliente_Promesa_Pago_Rota_EST
	,prz.cliente_prompago_cumplida_est AS Cliente_PromPago_Cumplida_EST
	,prz.cliente_prop_refaprobada_est AS cliente_prop_refaprobada_est
	,prz.cliente_prop_refrechazado_est AS cliente_prop_refrechazado_est
	,prz.cliente_rta_ult_accllm_est AS Cliente_Rta_Ult_AccLLM_EST
	,prz.cliente_valor_ult_acclla_est AS cliente_valor_ult_acclla_est
	,prz.cliente_valor_ult_accllm_est AS Cliente_Valor_ult_AccLLM_EST
	,prz.cliente_rta_ult_acc_anref_est AS Cliente_rta_ult_acc_AnRef_EST
	,prz.cliente_rta_ult_acc_llm_est AS Cliente_rta_ult_acc_LLM_EST
	,prz.cliente_val_ult_lla_i_est AS cliente_val_ult_lla_i_est
	,prz.cliente_c_datos_gest_tel AS Cliente_c_datos_gest_tel_
	,prz.cliente_cdatos_gest_corresp AS Cliente_cdatos_gest_corresp
	,prz.cliente_sin_dat_gest AS cliente_sin_dat_gest
	,prz.cliente_cambio_telefono AS cliente_cambio_telefono
	,prz.cliente_rta_ult_acclla_est AS cliente_rta_ult_acclla_est
	,prz.cliente_propde_refpendcie AS cliente_propde_refpendcie
	,prz.cliente_trabajado_cie AS cliente_trabajado_cie
	,prz.cliente_rta_ult_acc_bu_dat_est AS Cliente_rta_ult_acc_bu_dat_EST
	,prz.cliente_rta_ult_acc_val_re_est AS Cliente_rta_ult_acc_val_Re_EST
	,prz.cliente_rta_ultacc_res_sus_est AS cliente_rta_ultacc_res_sus_est
	,prz.cliente_jubilado AS cliente_jubilado
	,prz.cliente_funcionario_del_banco AS Cliente_Funcionario_del_Banco
	,prz.cliente_premium_ AS cliente_premium_
	,prz.Cliente_Inhibido_de_Gestion AS Cliente_Inhibido_de_Gestion
	,prz.cliente_vinculado_al_banco_ AS Cliente_Vinculado_al_Banco_
	,prz.cliente_banca AS Cliente_Banca
	,prz.cliente_por_campania_xxx_ AS cliente_por_campania_xxx_
	,prz.cliente_acredita_sueldo AS cliente_acredita_sueldo
	,prz.Cliente_fiduciario AS Cliente_Fiduciario
	,prz.login_responsable_baja AS login_responsable_baja
	,prz.cliente_tiene_celular AS cliente_tiene_celular
	,prz.cliente_tiene_e_mail AS cliente_tiene_e_mail
	,prz.Cliente_Mercado AS Cliente_Mercado
	,prz.Cliente_sub_Mercado AS Cliente_sub_Mercado
	,prz.cuenta_no_suspendida AS cuenta_no_suspendida
	,prz.cliente_1_prod_en_mora AS cliente_1_prod_en_mora
	,prz.deuda_venc_limite AS deuda_venc_limite
	,prz.reldvencdtotal_limite AS reldvencdtotal_limite
	,prz.cliente_de_1_producto AS cliente_de_1_producto
	,prz.producto_agencia AS producto_agencia
	,prz.cliente__cod_sub_segmento AS cliente__cod_sub_segmento
	,prz.Grupo_afinidad_SocMilitar AS Grupo_afinidad_SocMilitar
	,prz.cliente_ctaestadoquieb AS cliente_ctaestadoquieb
	,prz.cliente_ctaestadoconc AS cliente_ctaestadoconc
	,prz.cliente_ctaproductocomex AS cliente_ctaproductocomex
	,prz.cliente_ex_bt AS cliente_ex_bt
	,prz.Prod_Baja_Renta AS Prod_Baja_Renta
	,prz.Producto_Tar_Fogar AS Producto_Tar_Fogar
	,prz.empresa_fogar_cd AS empresa_fogar_cd
	,prz.cliente_ctaproductohipo AS cliente_ctaproductohipo
	,prz.cliente_prompago_pend AS Cliente_PromPago_Pend
	,prz.producto_cfi AS _Producto_CFI
	,prz.cliente_categoria AS Cliente_Categoria
	,prz.cliente_bst AS cliente_bst
	,prz.cliente_pago_ult_30_dias AS cliente_pago_ult_30_dias
	,prz.tiene_carta_garantia AS tiene_carta_garantia
	,prz.tiene_mora_garantia AS tiene_mora_garantia
	,prz.cli_canal_elect AS cli_canal_elect
	,prz.cta_con_carta AS cta_con_carta
	,prz.operacion_origen AS operacion_origen
	,prz.empresa_fogar AS empresa_fogar
	,prz.operacion_linea AS operacion_linea
	,prz.oper_cllm_welcome AS oper_cllm_welcome
	,prz.gaf_canales AS gaf_canales
	,prz.cliente_ex_bi AS Cliente_ex_BI
	,prz.cliente_ult2cobisop AS cliente_ult2cobisop
	,prz.cliente_ult2cobisvb AS cliente_ult2cobisvb
	,prz.cliente_valor_ult_accvbot_est AS cliente_valor_ult_accvbot_est
	,prz.cliente_ult2cobisivr AS cliente_ult2cobisivr
	,prz.oper_canales AS oper_canales
	,prz.cliente_ultima_accion AS cliente_ultima_accion
	,prz.producto_con_garante_sn AS producto_con_garante_sn
	,prz.Cliente_Eventual AS Cliente_Eventual
	,prz.COBIS_ULT_DIG_COBIS AS cliente_ult_dig_cobis
	-- agregados durante homologacion (definir si generar en precalculo o calcular directo en vista)
	, 0 id_usuario
	, 0 id_equipo
	, 0 id_cambio_usuario
	, 0 Cliente_ult_digito_dni
	, 0 id_zona
	, 0 id_agencia
	, 0 id_cambio_agencia
	, 0 id_cambio_estado
	, 0 id_cambio_escenario
FROM operacional.z_datos_calc_per prz--operacional.wfl_tper_objetos_proceso objprc
	INNER JOIN operacional.per_tpersonas per ON per.id_persona = prz.id_persona
	LEFT JOIN batch.per_pre_calculo_core pre_core  ON pre_core.id_persona = per.id_persona
	--LEFT JOIN operacional.z_datos_calc_per prz ON per.id_persona = prz.id_persona --TABLA CUSTOM PRECALCULO
    LEFT JOIN operacional.vw_wfl_tsituacion_gestion sit ON     sit.codigo_vista_gestion = 'vw_z_per_tsituacion_gestion'  AND per.id_persona = sit.id_objeto_gestion AND (sit.GRUPO_EJEC = 'DEFAULT' OR sit.GRUPO_EJEC IS NULL)
    LEFT JOIN batch.per_tultimas_acciones ulacc ON  PER.id_persona = ulacc.id_persona and ulacc.id_workflow = sit.id_workflow
    LEFT JOIN batch.per_tultimos_eventos ueve ON per.id_persona = ueve.id_persona  and sit.id_workflow = ueve.id_workflow
	LEFT JOIN (
            select prm.id_persona,situ.id_workflow,count(case when prm.alta_fecha > situ.fecha_estado then 1 else null end) existe_nueva_promesa_estado
            FROM operacional.x_prm_tpromesas prm
            LEFT JOIN operacional.vw_wfl_tsituacion_gestion situ ON  situ.codigo_vista_gestion = 'vw_z_per_tsituacion_gestion'  AND prm.id_persona = situ.id_objeto_gestion  AND (situ.GRUPO_EJEC = 'DEFAULT' OR situ.GRUPO_EJEC IS NULL)
            group by prm.id_persona,situ.id_workflow
          ) prmes on prmes.id_persona = per.id_persona and prmes.id_workflow = sit.id_workflow 
    LEFT JOIN (
		select cta.id_persona, max (datediff(day, cta.fecha_vencimiento, fec_apertura)) as dias_mora 
			from  operacional.cta_tcuentas cta
		inner join batch.bat_pparametros on 1=1 
		where  
			cta.baja = 0 
		group by cta.id_persona) cuentas ON cuentas.id_persona = per.id_persona 
	left join (select max(alta_fecha) fec_ult_promesa,id_persona from operacional.x_prm_tpromesas group by id_persona) ult_promesa_persona on ult_promesa_persona.id_persona = per.id_persona 
	left join (select codigo_met_estado_promesa,alta_fecha,id_persona from operacional.x_prm_tpromesas prm) cod_promesas on cod_promesas.id_persona = per.id_persona and cod_promesas.alta_fecha= ult_promesa_persona.fec_ult_promesa
	join batch.bat_pparametros tblParametros on tblParametros.id_parametro>0
	left join (select max(fecha_hora) fecha_hora from operacional.acc_tacciones nacc inner join operacional.acc_ptipos_acciones ntac on nacc.id_tipo_accion = ntac.id_tipo_accion and ntac.baja = 0 inner join operacional.acc_ptipos_respuestas ntrp on ntrp.id_tipo_accion = ntac.id_tipo_accion and ntrp.baja = 0 where codigo_met_tipo_accion = 'ACCTELOUT') FecUltLlamCierre on FecUltLlamCierre.fecha_hora > tblParametros.fec_cierre
	left join (select ntrp.codigo,fecha_hora from operacional.acc_tacciones nacc inner join operacional.acc_ptipos_acciones ntac on nacc.id_tipo_accion = ntac.id_tipo_accion and ntac.baja = 0 inner join operacional.acc_ptipos_respuestas ntrp on ntrp.id_tipo_accion = ntac.id_tipo_accion and ntrp.baja = 0 where codigo_met_tipo_accion = 'ACCTELOUT') UltLlamCierre on FecUltLlamCierre.fecha_hora = UltLlamCierre.fecha_hora
	left join (select max(nacc.fecha_hora ) fecha_hora,nacc.id_persona from operacional.acc_tacciones nacc inner join operacional.acc_ptipos_acciones ntac on nacc.id_tipo_accion = ntac.id_tipo_accion and ntac.baja = 0 inner join operacional.acc_ptipos_respuestas ntrp on ntrp.id_tipo_accion = ntac.id_tipo_accion and ntrp.baja = 0 where codigo_met_tipo_accion = 'ACCTELOUT' group by fecha_hora,id_persona) fecUtlLlamEst  on fecUtlLlamEst.fecha_hora > sit.fecha_estado AND fecUtlLlamEst.id_persona = per.id_persona
	left join (select ntrp.codigo,nacc.fecha_hora,nacc.id_persona from operacional.acc_tacciones nacc inner join operacional.acc_ptipos_acciones ntac on nacc.id_tipo_accion = ntac.id_tipo_accion and ntac.baja = 0 inner join operacional.acc_ptipos_respuestas ntrp on ntrp.id_tipo_accion = ntac.id_tipo_accion and ntrp.baja = 0 where codigo_met_tipo_accion = 'ACCTELOUT') Tbresp_ult_llm_est on Tbresp_ult_llm_est.fecha_hora > sit.fecha_estado AND Tbresp_ult_llm_est.id_persona = per.id_persona
	--WHERE ISNULL(per.entero1, 1) = 0 Filtro de personas HABITUALES
GO


