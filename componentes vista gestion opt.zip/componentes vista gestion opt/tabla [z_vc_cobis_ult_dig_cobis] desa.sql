USE [exelix]
GO

/****** Object:  Table [operacional].[z_vc_cobis_ult_dig_cobis]    Script Date: 09/04/2026 11:43:36 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [operacional].[z_vc_cobis_ult_dig_cobis](
	[id_persona] [int] NOT NULL,
	[cobis_ult_dig_cobis] [varchar](20) NULL,
PRIMARY KEY CLUSTERED 
(
	[id_persona] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO


